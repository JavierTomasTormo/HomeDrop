﻿<?php require_once("assets/inc/simpleHeader.php"); ?>
    <?php require_once("assets/inc/nav.php"); ?>
        
       <section id="home" class="head-main-img">
         
               <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-12">
              <h1>  OUR CONTACT DETAILS  </h1>
                </div>
               </div>
            </div>   
           
       </section>
    <!--/.HEADING END-->

<section  id="contact-sec">
       <iframe class="cnt" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2999841.293321206!2d-75.80920404999999!3d42.75594204999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew+York!5e0!3m2!1sen!2s!4v1395313088825" ></iframe>
  <div class="add">
 <i>Address: </i>234/JK , The Wondre Land,  Newyork Street Junction, JUST USA -10909094
   </div>
    <hr />
     </section>
      <section  class="note-sec" >
         
               <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 ">
                <i class="fa fa-quote-left fa-3x"></i>
               <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                            </p>
                </div>
               </div>
            </div>   
           
       </section>
    <!--/.NOTE END-->
     <section id="clients"  >
        
                
            <div class="container">
           <div class="row text-center pad-bottom" >
            <div class="col-md-12">
                <img src="assets/img/clients.png" alt="" class="img-responsive" />
            </div>
               
               </div>
        </div>
        </section>
     <!--/.CLIENTS END-->

<?php require_once("assets/inc/simpleFooter.php"); ?>
