﻿<?php require_once("assets/inc/simpleHeader.php"); ?>
    <?php require_once("assets/inc/nav.php"); ?>

        
   

 <section id="port-sec">
       <div class="container">
           
           <div class="row pad-row" >
                               <div class="col-md-12 col-sm-12" > 
                    <ul class="portfolio-items col-3"> 
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t1.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b1.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                       
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t2.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b2.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t3.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b3.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t4.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b4.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t5.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b5.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item ">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t6.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b6.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item ">
                           <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t7.png" alt="" />
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b7.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item ">
                           <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t8.png" alt="" />
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b8.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                         <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t9.png" alt="" />
                                    <div class="overlay">
                                        <a class="preview btn btn-primary" title="Image Title Here" href="assets/img/portfolio/big/b9.png">VIEW PROJECT</a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                    </ul>
                </div>
           </div>
       </div>
   </section>
     <!--/. END PORTFOLIO SECTION-->
      <section  class="note-sec" >
         
               <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 ">
                <i class="fa fa-quote-left fa-3x"></i>
               <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                            </p>
                </div>
               </div>
            </div>   
           
       </section>
    <!--/.NOTE END-->
     <section id="clients"  >
        
                
            <div class="container">
           <div class="row text-center pad-bottom" >
            <div class="col-md-12">
                <img src="assets/img/clients.png" alt="" class="img-responsive" />
            </div>
               
               </div>
        </div>
        </section>
     <!--/.CLIENTS END-->
     <?php require_once("assets/inc/simpleFooter.php"); ?>
      
    