<div class="navbar navbar-inverse navbar-fixed-top" >
        <div class="container">
            <div class="navbar-header">
                <h2 align="center"> <p class="texto-dorado">H&#920;M&#926;DR&#920;P</p></h2> 

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="../index.php">HOME</a></li>
                    <li><a href="../services.php">SERVICES</a></li>
                    <li><a href="../portfolio.php">PORTFOLIO</a></li>
                    <li><a href="../pricing.php">PRICING</a></li>
                    <li><a href="../contact.php">CONTACT</a></li>
                    <li><a href="../HomeDrop/index.php">HomeDrop Panel</a></li>
                </ul>
            </div>
           
        </div>
    </div>
   <!--/.NAVBAR END-->