<?php
    define("urlsite", "http://localhost/HomeDropTemplate/HomeDrop");
?>