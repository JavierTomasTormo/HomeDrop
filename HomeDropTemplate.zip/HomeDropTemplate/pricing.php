﻿<?php require_once("assets/inc/simpleHeader.php"); ?>
    <?php require_once("assets/inc/nav.php"); ?>
        
       <section class="head-main-img">
         
               <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-12">
              <h1>  PRICING OPTIONS </h1>
                </div>
               </div>
            </div>   
           
       </section>
    <!--/.HEADING END-->


        <section id="pricing-one">
            <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                             <h4>MEDIUM PLAN</h4> 
                            </div>
                            <div class="panel-body">

                               <ul class="plan">      
                                   <li class="price"><strong>10</strong> <i class="fa fa-dollar"></i></li>                       
                            <li><strong>52</strong> Emails</li>
                            <li><strong>50 GB</strong> Space</li>
                            <li><strong>Free</strong> Support</li>
                           </ul>
                            </div>
                            <div class="panel-footer">
                                <a href="#" class="btn btn-danger ">BUY NOW</a>
                            </div>
                        </div>
                    </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                             <h4>MEDIUM PLAN</h4> 
                            </div>
                            <div class="panel-body">

                               <ul class="plan">      
                                   <li class="price"><strong>25</strong> <i class="fa fa-dollar"></i></li>                       
                            <li><strong>52</strong> Emails</li>
                            <li><strong>50 GB</strong> Space</li>
                            <li><strong>Free</strong> Support</li>
                           </ul>
                            </div>
                            <div class="panel-footer">
                                <a href="#" class="btn btn-primary ">BUY NOW</a>
                            </div>
                        </div>
                    </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                             <h4>ECONOMY PLAN</h4> 
                            </div>
                            <div class="panel-body">

                               <ul class="plan">      
                                   <li class="price"><strong>50</strong> <i class="fa fa-dollar"></i></li>                       
                            <li><strong>52</strong> Emails</li>
                            <li><strong>50 GB</strong> Space</li>
                            <li><strong>Free</strong> Support</li>
                           </ul>
                            </div>
                            <div class="panel-footer">
                                <a href="#" class="btn btn-success ">BUY NOW</a>
                            </div>
                        </div>
                    </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                             <h4>ADVANCE PLAN</h4> 
                            </div>
                            <div class="panel-body">

                               <ul class="plan">      
                                   <li class="price"><strong>125</strong> <i class="fa fa-dollar"></i></li>                       
                            <li><strong>52</strong> Emails</li>
                            <li><strong>50 GB</strong> Space</li>
                            <li><strong>Free</strong> Support</li>
                           </ul>
                            </div>
                            <div class="panel-footer">
                                <a href="#" class="btn btn-info ">BUY NOW</a>
                            </div>
                        </div>
                    </div>
               
               </div>
        </div>
        </section>

    <!--/.PRICING-ONE END-->
     <section id="pricing-two">
            <div class="container">
           <div class="row text-center pad-row" >
                 <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="panel panel-danger adjust-border-radius">
                            <div class="panel-heading adjust-border">
                             <h4>BASIC PLAN</h4> 
                            </div>
                            <div class="panel-body">

                               <ul class="plan">      
                                   <li class="price-two"><strong>25</strong> <i class="fa fa-dollar"></i> <small>per month</small></li>                       
                            <li><i class="fa fa-paper-plane-o"></i><strong>1500 </strong> Emails Accounts</li>
                            <li><i class="fa fa-graduation-cap"></i><strong>5000 GB </strong>  Cloud Space</li>
                            <li><i class="fa fa-bomb"></i><strong>230 </strong> Support Queries </li>
                                     <li><i class="fa fa-bookmark-o"></i><strong>1500 </strong> Emails Accounts</li>
                            <li><i class="fa fa-bolt"></i><strong>5000 GB </strong>  Cloud Space</li>
                            <li><i class="fa fa-bars"></i><strong>230 </strong> Support Queries </li>
                           </ul>
                            </div>
                            <div class="panel-footer">
                                <a href="#" class="btn btn-danger btn-block btn-lg adjust-border-radius">BUY NOW</a>
                            </div>
                        </div>
                    </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="panel panel-primary adjust-border-radius">
                            <div class="panel-heading adjust-border">
                             <h4>MEDIUM PLAN</h4> 
                            </div>
                            <div class="panel-body">

                               <ul class="plan">      
                                   <li class="price-two"><strong>45</strong> <i class="fa fa-dollar"></i><small>per month</small></li>                       
                             <li><i class="fa fa-paper-plane-o"></i><strong>1500 </strong> Emails Accounts</li>
                            <li><i class="fa fa-graduation-cap"></i><strong>5000 GB </strong>  Cloud Space</li>
                            <li><i class="fa fa-bomb"></i><strong>230 </strong> Support Queries </li>
                                     <li><i class="fa fa-bookmark-o"></i><strong>1500 </strong> Emails Accounts</li>
                            <li><i class="fa fa-bolt"></i><strong>5000 GB </strong>  Cloud Space</li>
                            <li><i class="fa fa-bars"></i><strong>230 </strong> Support Queries </li>
                           </ul>
                            </div>
                            <div class="panel-footer">
                                <a href="#" class="btn btn-primary btn-block btn-lg adjust-border-radius">BUY NOW</a>
                            </div>
                        </div>
                    </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="panel panel-success adjust-border-radius">
                            <div class="panel-heading adjust-border">
                             <h4>ADVANCE PLAN</h4> 
                            </div>
                            <div class="panel-body">

                               <ul class="plan">      
                                   <li class="price-two"><strong>95</strong> <i class="fa fa-dollar"></i><small>per month</small></li>                       
                             <li><i class="fa fa-paper-plane-o"></i><strong>1500 </strong> Emails Accounts</li>
                            <li><i class="fa fa-graduation-cap"></i><strong>5000 GB </strong>  Cloud Space</li>
                            <li><i class="fa fa-bomb"></i><strong>230 </strong> Support Queries </li>
                                     <li><i class="fa fa-bookmark-o"></i><strong>1500 </strong> Emails Accounts</li>
                            <li><i class="fa fa-bolt"></i><strong>5000 GB </strong>  Cloud Space</li>
                            <li><i class="fa fa-bars"></i><strong>230 </strong> Support Queries </li>
                           </ul>
                            </div>
                            <div class="panel-footer">
                                <a href="#" class="btn btn-success btn-block btn-lg adjust-border-radius">BUY NOW</a>
                            </div>
                        </div>
                    </div>
               </div>
                </div>
         </section>
    <!--/.PRICING-TWO END-->
      <section  class="note-sec" >
         
               <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 ">
                <i class="fa fa-quote-left fa-3x"></i>
               <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                            </p>
                </div>
               </div>
            </div>   
           
       </section>
    <!--/.NOTE END-->
     <section id="clients"  >
        
                
            <div class="container">
           <div class="row text-center pad-bottom" >
            <div class="col-md-12">
                <img src="assets/img/clients.png" alt="" class="img-responsive" />
            </div>
               
               </div>
        </div>
        </section>
     <!--/.CLIENTS END-->



<?php require_once("assets/inc/simpleFooter.php"); ?>
