﻿<?php require_once("assets/inc/simpleHeader.php"); ?>
    <?php require_once("assets/inc/nav.php"); ?>
        
       <section id="home" class="head-main-img">
         
               <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-12">
              <h1>  OUR SERVICES  </h1>
                </div>
               </div>
            </div>   
           
       </section>
    <!--/.HEADING END-->

 <section >
             <div class="container">
             <div class="row text-center pad-row">
            <div class="col-md-4  col-sm-4">
                 <i class="fa fa-desktop fa-5x"></i>
                            <h4> <strong>Sure Quique Menu</strong> </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                       <a href="#" class="btn btn-primary" >Read Details</a>    
                </div>
             <div class="col-md-4  col-sm-4">
                 <i class="fa fa-bomb fa-5x"></i>
                            <h4> <strong>Sure Quique Menu</strong> </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                           <a href="#" class="btn btn-primary" >Read Details</a>
                </div>
            <div class="col-md-4  col-sm-4">
                  <i class="fa fa-plus  fa-5x"></i>
                            <h4> <strong>Sure Quique Menu</strong> </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                       <a href="#" class="btn btn-primary" >Read Details</a>    
                </div>

                    
            </div>
                 <div class="row text-center pad-row">
            <div class="col-md-4  col-sm-4">
                 <i class="fa fa-edit fa-5x"></i>
                            <h4> <strong>Sure Quique Menu</strong> </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                       <a href="#" class="btn btn-primary" >Read Details</a>    
                </div>
             <div class="col-md-4  col-sm-4">
                 <i class="fa fa-comments-o fa-5x"></i>
                            <h4> <strong>Sure Quique Menu</strong> </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                           <a href="#" class="btn btn-primary" >Read Details</a>
                </div>
            <div class="col-md-4  col-sm-4">
                  <i class="fa fa-pencil  fa-5x"></i>
                            <h4> <strong>Sure Quique Menu</strong> </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                       <a href="#" class="btn btn-primary" >Read Details</a>    
                </div>

                    
            </div>
                 </div>
         </section>
      <section  class="note-sec" >
         
               <div class="container">
           <div class="row text-center pad-row" >
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 ">
                <i class="fa fa-quote-left fa-3x"></i>
               <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                            </p>
                </div>
               </div>
            </div>   
           
       </section>
    <!--/.NOTE END-->
     <section id="clients"  >
        
                
            <div class="container">
           <div class="row text-center pad-bottom" >
            <div class="col-md-12">
                <img src="assets/img/clients.png" alt="" class="img-responsive" />
            </div>
               
               </div>
        </div>
        </section>

     <!--/.CLIENTS END-->
     <?php require_once("assets/inc/simpleFooter.php"); ?>


