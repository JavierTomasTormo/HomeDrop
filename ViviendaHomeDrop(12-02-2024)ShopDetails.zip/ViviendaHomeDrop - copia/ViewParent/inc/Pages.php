<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['Pages'])) {
    $_SESSION['Pages'] = "ListHomeDrop";
}

$Pages = $_SESSION['Pages'];

if (isset($_GET['page']) && $_GET['page'] === "Shop") {
    $_SESSION['TopPage'] = "Shop";
}




// Obtener la página TopPage ::si no está definida sE establece como ListHomeDrop por defecto
$TopPage = isset($_SESSION['TopPage']) ? $_SESSION['TopPage'] : "ListHomeDrop";

//echo "pages de index.html ::::$Pages";

switch ($Pages) {
    case "ListHomeDrop":
        include_once('Module/HomeDropModule/Vista/ListHomeDrop.html');
    break;

    case "Controller_HomeDrop":
        include_once("Module/HomeDropModule/Controlador/Controller_HomeDrop.php");
    break;

    case "Shop":
        //TESTING PAGE
        include_once('Module/Shop/ViewShop/inc/Shop.html');
    break;

    // case "ControllerShop":
    //     include_once("Module/Shop/ControllerShop/ControllerShop.php");
    // break;

    case "404":
    case "503":
        include_once("ViewParent/inc/$Pages.html");
    break;

    default:
        $_SESSION['Pages'] = "ListHomeDrop";
    break;
}




















/*
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si la variable de sesión Pages no está definida
if (!isset($_SESSION['Pages'])) {
    $_SESSION['Pages'] = "ListHomeDrop";
}

$Pages = $_SESSION['Pages'];

//echo "pages de index.html ::::$Pages";

switch ($Pages) {
    case "ListHomeDrop":
        include_once('Module/HomeDropModule/Vista/ListHomeDrop.html');
        break;

    case "Controller_HomeDrop":
        include_once("Module/HomeDropModule/Controlador/Controller_HomeDrop.php");
        break;

    case "Shop":
        //TESTING PAGE
        include_once('Module/Shop/ViewShop/inc/Shop.html');
        break;

    case "ControllerShop":
        include_once("Module/Shop/ControllerShop/ControllerShop.php");
        break;

    case "404":
    case "503":
        include_once("ViewParent/inc/$Pages.html");
        break;

    default:
        $_SESSION['Pages'] = "ListHomeDrop";
        break;
}*/
?>