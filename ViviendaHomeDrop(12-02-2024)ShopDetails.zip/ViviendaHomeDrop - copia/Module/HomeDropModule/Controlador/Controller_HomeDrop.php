<?php
    $path = $_SERVER['DOCUMENT_ROOT'] . '/ViviendaHomeDrop/';
    include($path . "Module/HomeDropModule/Modelo/DAOHomeDrop.php");

    // include("/ViviendaHomeDrop/Module/HomeDropModule/Modelo/DAOHomeDrop.php");

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
    switch ($_GET['Option']) {
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
            case 'List';
                include('Module/HomeDropModule/Vista/ListHomeDrop.html');
        break;
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
        case 'City';
            //$data = 'City checkpoint';
            //die('<script>console.log(' . json_encode($data) . ');</script>');
            try {
                $DAOHomeDrop = new DAOHomeDrop();
                $SelectCity = $DAOHomeDrop->SelectCity();

            } catch (Exception $e) {
                echo json_encode("Error: Exception ", $e);

            }
            if (!empty($SelectCity)) {
                echo json_encode($SelectCity);

                
            } else {
                echo json_encode("Error: JSON Encode");

            }
        break;
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
        case 'Category';
            //$data = 'Category Checkpoint';
            //die('<script>console.log(' . json_encode($data) . ');</script>');
            try {
                $DAOHomeDrop = new DAOHomeDrop();
                $SelectCategory = $DAOHomeDrop->SelectCategory();

            } catch (Exception $e) {
                echo json_encode("Error: Exception ", $e);

            }
            if (!empty($SelectCategory)) {
                echo json_encode($SelectCategory);

            } else {
                echo json_encode("Error: JSON Encode");

            }
        break;

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
        case 'Muestra';

            try {
                $DAOHomeDrop = new DAOHomeDrop();
                $CarouselMuestras = $DAOHomeDrop->CarouselMuestras();

            } catch (Exception $e) {
                echo json_encode("Error: Exception ", $e);

            }
            if (!empty($CarouselMuestras)) {
                echo json_encode($CarouselMuestras);

            } else {
                echo json_encode("Error: JSON Encode");

            }
        break;
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
        case 'Operation';
            //$data = 'Checkpoint Operation';
            //die('<script>console.log(' . json_encode($data) . ');</script>');
            try {
                $DAOHomeDrop = new DAOHomeDrop();
                $SelectOperation = $DAOHomeDrop->SelectOperation();

            } catch (Exception $e) {
                echo json_encode("Error: Exception ", $e);

            }
            if (!empty($SelectType)) {
                echo json_encode($SelectType);

            } else {
                echo json_encode("Error: JSON Encode");

            }
        break;
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
        default;
            include("ViewParent/inc/util/error404.html");
        break;
}//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//


?>



