//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
                    //Cargar el Carrusel de Imágenes//
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
function CarouselImages() {
    //console.log('LLega al carr IMG');
    ajaxPromise('Module/HomeDropModule/Controlador/Controller_HomeDrop.php?Option=Muestra', 'GET', 'JSON')

        .then(function (data) {

            for (let row = 0; row < data.length; row++) {
                $('<div></div>')
                    .attr('class', 'carousel__elements')
                    .attr('id', data[row].ID_Muestra)
                    .appendTo('.CarouselImages')
                    .html(
                        "<div class='overlay'>" +
                            "<img class='carousel__img' src='" + data[row].Img + "' alt=''>" +
                            "<p class='pdp'>" + data[row].Type + "</p>" +
                        "</div>"
                    );
            }

            new Glider(document.querySelector('.CarouselImages'), {
                slidesToShow: 1.05,
                slidesToScroll: 1, 
                draggable: false,
                dots: '.carousel__indicadores',
                arrows: {
                    prev: '.carousel__anterior',
                    next: '.carousel__siguiente'
                },
                rewind: true,

            });
        

              //console.log('Succesfuly'); 
        })
        .catch(function () {
            console.log('ErrorO');
        });
}

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
                        // Cargar las Categorías //
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
function CategoryCharger() {
    //console.log('LLega al CategoryCharger');
    ajaxPromise('Module/HomeDropModule/Controlador/Controller_HomeDrop.php?Option=Category', 'GET', 'JSON')
        .then(function (data) {
            //console.log(data);

            for (let row = 0; row < data.length; row++) {
               // console.log(data);


                $('<div></div>')
                  .attr('class', 'glider-item')
                  .attr('id', data[row].ID_Category)
                  .appendTo('#second-glider')
                  .html(
                    "<div class='overlayCategory'>" +
                        "<img class='carousel__img' src='" + data[row].Img + "' alt=''>" +
                        "<p class='pdpCategory'>" + data[row].Category + "</p>" +
                    "</div>"
                    );
              }

              new Glider(document.getElementById('second-glider'), {
                slidesToShow: 5.2,
                slidesToScroll: 1,
                scrollLock: true,
                draggable: false,
                rewind: true,
                arrows: {
                  prev: document.querySelector(".carousel__anteriorDOS"),
                  next: document.querySelector(".carousel__siguienteDOS")
                },
                responsive: [
                  {
                    // screens greater than > 400px
                    breakpoint: 400,
                    settings: {
                      slidesToShow: 5.2,
                      slidesToScroll: 1,
                      duration: 1
                    }
                  },
                  {
                    // screens greater than > 700px
                    breakpoint: 700,
                    settings: {
                      slidesToShow: 5.2,
                      slidesToScroll: 1,
                      duration: 1
                    }
                  },
                  {
                    // screens greater than > 1300px
                    breakpoint: 1300,
                    settings: {
                      slidesToShow: 5.2,
                      slidesToScroll: 1,
                      duration: 1
                    }
                  }
                ]
              });

               

        }).catch(function () {
            //Controller exceptions
            //window.location.href = "index.php?module=ctrl_exceptions&op=503&type=503&lugar=Type_Categories HOME";
        });
}

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
                            //Cargar las Ciudades//
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
function CityCharger() {
    //console.log('LLega al Cargar_Ciudades');
    ajaxPromise('Module/HomeDropModule/Controlador/Controller_HomeDrop.php?Option=City', 'GET', 'JSON')
        .then(function (data) {
            //console.log(data);
            for (let row = 0; row < data.length; row++) {
                // console.log(data);
                 $('<div></div>')
                   .attr('class', 'glider-item')
                   .attr('id', data[row].ID_City)
                   .appendTo('#third-glider')
                   .html(
                     "<div class='overlayCity'>" +
                         "<img class='carousel__img' src='" + data[row].Img + "' alt=''>" +
                         "<p class='pdpCity'>" + data[row].Ciudad + "</p>" +
                     "</div>"
                     );
            }
            new Glider(document.getElementById('third-glider'), {
                slidesToShow: 5,
                slidesToScroll: 1,
                scrollLock: true,
                draggable: false,
                rewind: true,
                responsive: [
                  {
                    // screens greater than > 400px
                    breakpoint: 400,
                    settings: {
                      slidesToShow: 5,
                      slidesToScroll: 1,
                      duration: 1
                    }
                  },
                  {
                    // screens greater than > 700px
                    breakpoint: 700,
                    settings: {
                      slidesToShow: 5,
                      slidesToScroll: 1,
                      duration: 1
                    }
                  },
                  {
                    // screens greater than > 1300px
                    breakpoint: 1300,
                    settings: {
                      slidesToShow: 5,
                      slidesToScroll: 1,
                      duration: 1
                    }
                  }
                ]
              });
        }).catch(function () {
            //console.log('Error');
        });
}
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
                            //Cargar las Operaciones//
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
function OperationCharger() {
    //console.log('LLega al Cargar_Tipo');
    ajaxPromise('Module/HomeDropModule/Controlador/Controller_HomeDrop.php?Option=Operation', 'GET', 'JSON')
        .then(function (data) {
            //console.log(data);
            for (let row = 0; row < data.length; row++) {
              // console.log(data);
               $('<div></div>')
                 .attr('class', 'glider-item')
                 .attr('id', data[row].ID_Operation)
                 .appendTo('#fourth-glider')
                 .html(
                   "<div class='overlayCity'>" +
                       "<img class='carousel__img' src='" + data[row].Img + "' alt=''>" +
                       "<p class='pdpCity'>" + data[row].Operation + "</p>" +
                   "</div>"
                   );
            }

            
              
        }).catch(function () {
           /// window.location.href = "index.php?module=ctrl_exceptions&op=503&type=503&lugar=Types_car HOME";
        });
}

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
                        // Document Ready //
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
$(document).ready(function () {
    CarouselImages();
    CategoryCharger();
    CityCharger();
    OperationCharger();
});


