<?php
$path = $_SERVER['DOCUMENT_ROOT'] . '/ViviendaHomeDrop/';

include($path . "Model/Connect.php");

//include("/ViviendaHomeDrop/Model/Connect.php");

class DAOHomeDrop{
//##########################################################################//
	function CarouselMuestras() {

		$sql= "SELECT * FROM `typehomedrop` ORDER BY ID_Type ASC LIMIT 25;";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql);
		connect::close($conexion);

		$retrArray = array();
		if (mysqli_num_rows($res) > 0) {
			while ($row = mysqli_fetch_assoc($res)) {
				$retrArray[] = $row;
			}
		}
		return $retrArray;
	}	
//##########################################################################//
	function SelectType() {
		$sql = "SELECT * FROM `typehomedrop` ORDER BY ID_Type ASC LIMIT 25;";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql);
		connect::close($conexion);

		$retrArray = array();
		if (mysqli_num_rows($res) > 0) {
			while ($row = mysqli_fetch_assoc($res)) {
				$retrArray[] = $row;
			}
		}
		return $retrArray;
	}
//##########################################################################//
	function SelectCity() {
		$sql = "SELECT * FROM `cityhomedrop` ORDER BY ID_City ASC LIMIT 25;";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql);
		connect::close($conexion);

		$retrArray = array();
		if (mysqli_num_rows($res) > 0) {
			while ($row = mysqli_fetch_assoc($res)) {
				$retrArray[] = $row;
			}
		}
		return $retrArray;
	}
//##########################################################################//
	function SelectCategory() {
		$sql = "SELECT * FROM `categoryhomedrop` ORDER BY ID_Category ASC LIMIT 25;";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql);
		connect::close($conexion);

		$retrArray = array();
		if (mysqli_num_rows($res) > 0) {
			while ($row = mysqli_fetch_assoc($res)) {
				$retrArray[] = $row;
			}
		}
		return $retrArray;
	}
//##########################################################################//
	function SelectOperation() {
		$sql = "SELECT * FROM `operationhomedrop` ORDER BY ID_Operation DESC";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql);
		connect::close($conexion);

		$retrArray = array();
		if (mysqli_num_rows($res) > 0) {
			while ($row = mysqli_fetch_assoc($res)) {
				$retrArray[] = $row;
			}
		}
		return $retrArray;
	}
//##########################################################################//
//##########################################################################//
//##########################################################################//
}


/*
	function Seleccionar_Categoria() {
		$sql = "SELECT * FROM categoria";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql);
		connect::close($conexion);

		$retrArray = array();
		if (mysqli_num_rows($res) > 0) {
			while ($row = mysqli_fetch_assoc($res)) {
				$retrArray[] = $row;
			}
		}
		return $retrArray;
	}
*/