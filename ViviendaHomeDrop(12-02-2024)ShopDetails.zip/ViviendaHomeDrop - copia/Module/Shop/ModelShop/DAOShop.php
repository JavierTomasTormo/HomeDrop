<?php
$path = $_SERVER['DOCUMENT_ROOT'] . '/ViviendaHomeDrop/';
include($path . "Model/Connect.php");

class DAOShop{
	function SelectAllHomes(){
/*-------*/
        // echo json_encode("Llego al DAOShop");
        // break;
		$sql = "SELECT vh.ID_HomeDrop, vh.Precio, vh.Superficie, ch.Ciudad, ch.Calle, th.Type, oh.Operation, ih.ID_Imagen, ih.ID_HomeDrop, ih.Img
		FROM viviendashomedrop vh
			LEFT JOIN cityhomedrop ch ON vh.ID_City = ch.ID_City
			LEFT JOIN viviendastype vht ON vh.ID_HomeDrop = vht.ID_HomeDrop
			LEFT JOIN typehomedrop th ON vht.ID_Type = th.ID_Type
			LEFT JOIN viviendasoperation vho ON vh.ID_HomeDrop = vho.ID_HomeDrop
			LEFT JOIN operationhomedrop oh ON vho.ID_Operation = oh.ID_Operation
			LEFT JOIN imageneshomedrop ih ON ih.ID_HomeDrop = vh.ID_HomeDrop
			GROUP BY vh.ID_HomeDrop;";

				$conexion = connect::con();
				$res = mysqli_query($conexion, $sql);
				connect::close($conexion);

				$retrArray = array();
				if (mysqli_num_rows($res) > 0) {
					while ($row = mysqli_fetch_assoc($res)) {
						$retrArray[] = $row;
					}
				}
				return $retrArray;
	}
/*-------*/



/*-------*/
	function SelectOneHome($id){
		$sql = "SELECT vh.ID_HomeDrop, vh.Precio, vh.Superficie, ch.Ciudad, ch.Calle, th.Type, oh.Operation, ih.ID_Imagen
				FROM viviendashomedrop vh 
				LEFT JOIN cityhomedrop ch ON vh.ID_City = ch.ID_City 
				LEFT JOIN viviendastype vht ON vh.ID_HomeDrop = vht.ID_HomeDrop 
				LEFT JOIN typehomedrop th ON vht.ID_Type = th.ID_Type 
				LEFT JOIN viviendasoperation vho ON vh.ID_HomeDrop = vho.ID_HomeDrop 
				LEFT JOIN operationhomedrop oh ON vho.ID_Operation = oh.ID_Operation 
				LEFT JOIN imageneshomedrop ih ON ih.ID_HomeDrop = vh.ID_HomeDrop 
				WHERE vh.ID_HomeDrop = $id
				GROUP BY vh.ID_HomeDrop";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql)->fetch_object();
		//connect::close($conexion);

		return $res;
	}

//-------//
	function SelectImagesHomes($id){
		$sql = "SELECT vh.ID_HomeDrop, ih.ID_Imagen, ih.Img 
				FROM viviendashomedrop vh 
				LEFT JOIN imageneshomedrop ih ON ih.ID_HomeDrop = vh.ID_HomeDrop 
				WHERE vh.ID_HomeDrop = $id";

		$conexion = connect::con();
		$res = mysqli_query($conexion, $sql);
		connect::close($conexion);

		$imgArray = array();
		if (mysqli_num_rows($res) > 0) {
			foreach ($res as $row) {
				array_push($imgArray, $row);
			}
		}
		return $imgArray;
	}


/*-------*/
}
