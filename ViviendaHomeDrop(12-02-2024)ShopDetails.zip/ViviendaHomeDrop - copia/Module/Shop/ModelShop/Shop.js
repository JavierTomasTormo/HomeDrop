

$(document).ready(function() {
    //console.log('DocumentReady');
    //Hasta aqui llega

    LoadHomeDropShop();
    clicks();
});
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·//
/*LoadHomeDropShop(false);
//ready

function LoadHomeDropShop(loadData) {
console.log("Hola2");

if (loadData || typeof loadData === 'undefined') {
    ajaxForSearch('Module/Shop/ControllerShop/ControllerShop.php?Option=All_Homes');
}*/

function LoadHomeDropShop() {
    //console.log("Hola2");
    //Hasta aqui LLega2

    ajaxForSearch('Module/Shop/ControllerShop/ControllerShop.php?Option=AllHomes');
}

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·//

function ajaxForSearch(url) {
    ajaxPromise(url, 'GET', 'JSON')
        .then(function(data) {

            //////////
            // console.log(data);
            /////////LLEGA HASTA AQUIIIIIIIIIIII
            $('#ListViviendasHomeDrop').empty();

            //Mejora para que cuando no hayan resultados en los filtros aplicados
            if (data == "error") {
                $('<div></div>').appendTo('#ListViviendasHomeDrop')
                    .html(
                        '<h3>¡No se encuentran resultados con los filtros aplicados!</h3>'
                    );
            } else {
                for (row in data) {
                    $('<div></div>').attr({ 'id': data[row].ID_HomeDrop, 'class': 'list_content_shop' }).appendTo('#ListViviendasHomeDrop')
                        .html(
                            '<div class="container">' +
                                '<div class="wrapper">' +
                                    '<div class="product-img">' +
                                        '<img src="' + data[row].Img + '" style="height: 420px; width: 327px; object-fit: cover;">' +
                                    '</div>' +
                                    '<div class="product-info">' +
                                        '<div class="product-text">' +
                                            '<h1><b>' + data[row].Type + ' <h2><b>' + data[row].Operation + '</b></h2><a class="list__heart" id="' + data[row].Ciudad + '"><i id="' + data[row].Superficie + '" class=""></i></a></b></h1>' +
                                            '<p>' + data[row].Calle + '</p>' +
                                            '<h3> Descripción y Detalles: </h3>' +
                                            '<p> Próximamente... </p>' +
                                        '</div>' +
                                        '<br/><div class="product-price-btn">' +
                                            '<p><span>' + data[row].Precio + '€</span></p><br/>' +
                                            '<button id="' + data[row].ID_HomeDrop + '" type="button" class="button buy">Details</button>' +
                                        '</div>' +
                                    '</div>' +
                                '</div>' +
                            '</div>'
                        );

                }//endfor
            }//endelse
            
        }).catch(function() {
            //window.location.href = "index.php?module=ctrl_exceptions&op=503&type=503&lugar=Function ajxForSearch SHOP";
        });
}
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·//

function clicks() {
    $(document).on("click", ".button.buy", function() {
        var ID_HomeDrop = this.getAttribute('id');
        //console.log(ID_HomeDrop);
        loadDetails(ID_HomeDrop);
    });
}

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·//

function loadDetails(ID_HomeDrop) {
    //REZAMOS A JESUCRISTO NUESTRO SEÑOR
    //console.log(ID_HomeDrop);
    //console.log("La ID llega Intacta");
    //return false;
    ajaxPromise('Module/Shop/ControllerShop/ControllerShop.php?Option=DetailsHome&id=' + ID_HomeDrop, 'GET', 'JSON')
    .then(function(data) {
        ///////////////////////////////
        console.log("Hola, ya llego a pasar las Promises");
        console.log(data);


        $('#content_shop_cars').empty();
        $('.date_img_dentro').empty();
        $('.date_car_dentro').empty();

        for (row in data[1][0]) {
            $('<div></div>').attr({ 'id': data[1][0].id_img, class: 'date_img_dentro' }).appendTo('.date_img')
                .html(
                    "<div class='content-img-details'>" +
                    "<img src= '" + data[1][0][row].img_cars + "'" + "</img>" +
                    "</div>"
                )
        }

        $('<div></div>').attr({ 'id': data[0].id_car, class: 'date_car_dentro' }).appendTo('.date_car')
            .html(
                "<div class='list_product_details'>" +
                "<div class='product-info_details'>" +
                "<div class='product-content_details'>" +
                "<h1><b>" + data[0].id_brand + " " + data[0].name_model + "</b></h1>" +
                "<hr class=hr-shop>" +
                "<table id='table-shop'> <tr>" +
                "<td> <i id='col-ico' class='fa-solid fa-road fa-2xl'></i> &nbsp;" + data[0].Km + "KM" + "</td>" +
                "<td> <i id='col-ico' class='fa-solid fa-person fa-2xl'></i> &nbsp;" + data[0].gear_shift + "</td>  </tr>" +
                "<td> <i id='col-ico' class='fa-solid fa-car fa-2xl'></i> &nbsp;" + data[0].name_cat + "</td>" +
                "<td> <i id='col-ico' class='fa-solid fa-door-open fa-2xl'></i> &nbsp;" + data[0].num_doors + "</td>  </tr>" +
                "<td> <i id='col-ico' class='fa-solid fa-gas-pump fa-2xl'></i> &nbsp;" + data[0].name_tmotor + "</td>" +
                "<td> <i id='col-ico' class='fa-solid fa-calendar-days fa-2xl'></i> &nbsp;" + data[0].matricualtion_date + "</td>  </tr>" +
                "<td> <i id='col-ico' class='fa-solid fa-palette fa-2xl'></i> &nbsp;" + data[0].color + "</td>" +
                "<td> <i class='fa-solid fa-location-dot fa-2xl'></i> &nbsp;" + data[0].city + "</td> </tr>" +
                "</table>" +
                "<hr class=hr-shop>" +
                "<h3><b>" + "More Information:" + "</b></h3>" +
                "<p>This vehicle has a 2-year warranty and reviews during the first 6 months from its acquisition.</p>" +
                "<div class='buttons_details'>" +
                "<a class='button add' href='#'>Add to Cart</a>" +
                "<a class='button buy' href='#'>Buy</a>" +
                "<span class='button' id='price_details'>" + data[0].price + "<i class='fa-solid fa-euro-sign'></i> </span>" +
                "<a class='details__heart' id='" + data[0].id_car + "'><i id=" + data[0].id_car + " class='fa-solid fa-heart fa-lg'></i></a>" +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div>"
            )

        $('.date_img').slick({
            infinite: true,
            speed: 300,
            slidesToShow: 1,
            adaptiveHeight: true,
            autoplay: true,
            autoplaySpeed: 1500
        });
    }).catch(function() {
        // window.location.href = "index.php?module=ctrl_exceptions&op=503&type=503&lugar=Load_Details SHOP";
    });
}


