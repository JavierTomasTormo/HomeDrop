<?php
$path = $_SERVER['DOCUMENT_ROOT'] . '/ViviendaHomeDrop/';
include($path . "Module/Shop/ModelShop/DAOShop.php");


//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//
switch ($_GET['Option']) {
//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//

    case 'ListShop':
        include('Module/Shop/ViewShop/inc/Shop.html');
    break;

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//

    case 'AllHomes':
        //Llego aqui 3
        // echo json_encode("Llego al Controller Shop");
        // break;

        try {
            $DAOshop = new DAOShop();
            $DatosHome = $DAOshop->SelectAllHomes();
        } catch (Exception $e) {
            echo json_encode("error");
        }

        if (!empty($DatosHome)) {
            echo json_encode($DatosHome);
        } else {
            echo json_encode("error");
        }
    break;




//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//

    case 'DetailsHome':
        /*
        $response = array(
            "message" => "Llego a DetailsHome con id intacta!",
            "id" => $_GET['id']
        );
        echo json_encode($response);
        break;
        */

        try {
            $DAOShop = new DAOShop();
            $Date_Home = $DAOShop->SelectOneHome($_GET['id']);
            
        } catch (Exception $e) {
            echo json_encode("error");
            exit;
        }


        try {
            $DAOShop_Img = new DAOShop();
            $Date_Img = $DAOShop_Img->SelectImagesHomes($_GET['id']);

        } catch (Exception $e) {
            echo json_encode("error");
            exit; 
        }


        if (!empty($Date_Home) || !empty($Date_Img)) {
            $rdo = array();
            $rdo[0] = $Date_Home;
            $rdo[1][] = $Date_Img;
            echo json_encode($rdo);
        } else {
            
            echo json_encode("error");
        }
        
        
    break;

//#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#·#//

    default;
        include("ViewParent/inc/error404.html");
    break;
}
